package Task1;

public class VCoffeeTable implements CoffeeTable {
public void hasCoffee() {
    System.out.println("victorian Coffee Table has 8 cup");
}


    public void hasSeats() {
        System.out.println("victorian Coffee Table has 4 seats");
    }

}
