package Task1;

public class VChair implements Chair{
    public void hasLegs() {
        System.out.println("victorian chair has 4 legs");
    }


    public void setOn() {
        System.out.println("can sit on victorian chair");
    }


    public void hasSeats() {
        System.out.println(" victorian chair has 1 seat");
    }
}
