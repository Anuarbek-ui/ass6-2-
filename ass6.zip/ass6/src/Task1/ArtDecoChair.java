package Task1;

public class ArtDecoChair implements Chair {

    public void hasLegs() {
        System.out.println("artDeco Chair has 3 legs;");
    }


    public void setOn() {
        System.out.println("can sit on artDeco");
    }


    public void hasSeats() {
        System.out.println("actDeco Chair has two seats");
    }
}
