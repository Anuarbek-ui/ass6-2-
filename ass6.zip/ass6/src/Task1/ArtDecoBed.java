package Task1;

public class ArtDecoBed implements Bed {

    public void hasLegs() {
        System.out.println("artDeco bed has 5 legs;");
    }


    public void hasSeats() {
        System.out.println("artDeco bed has 3 seats");
    }


    public void setOn() {
        System.out.println("can sit on artDeco");
    }


    public void lieOn() {
        System.out.println("can lie on actDeco bed");
    }
}
