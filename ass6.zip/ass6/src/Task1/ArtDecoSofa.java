package Task1;

public class ArtDecoSofa implements Sofa {
public void hasLegs() {
    System.out.println("artDeco sofa has 4 legs;");
}


    public void setOn() {
        System.out.println("can sit on artDeco sofa");
    }


    public void hasSeats() {
        System.out.println("artDeco sofa has 5 seats;");
    }


    public void lieOn() {
        System.out.println("can lie on artDeco sofa");
    }
}
