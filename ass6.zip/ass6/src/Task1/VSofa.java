package Task1;

public class VSofa extends Sofa {
public void hasLegs() {
    System.out.println("victorian sofa has 8 legs");
}


    public void setOn() {
        System.out.println("victorian sofa has 4 seats");
    }


    public void hasSeats() {
        System.out.println("can sit on victorian sofa");
    }


    public void lieOn() {
        System.out.println("victorian sofa has 1 seat");
    }
}
