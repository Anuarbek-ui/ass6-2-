package Task1;

public class VBed implements Bed {
public void hasLegs() {
    System.out.println("victorian bed has 8 legs");
}


    public void hasSeats() {
        System.out.println("victorian bed has 4 seats");
    }


    public void setOn() {
        System.out.println("can sit on victorian bed");
    }


    public void lieOn() {
        System.out.println("can lie on victorian bed");
    }
}
