package Task1;

public class ArtDecoCoffeeTable implements CoffeeTable {

    public void hasCoffee() {
        System.out.println("artDeco coffee table has 5 cup;");
    }


    public void hasSeats() {
        System.out.println("artDeco coffee table has 3 seats");
    }

}
