package Task1;

public interface Chair  {
    public void hasLegs();
    public void setOn();
    public void hasSeats();
}
