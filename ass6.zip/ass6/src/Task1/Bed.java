package Task1;

public interface Bed  {
    public void hasLegs();
    public void hasSeats();
    public void setOn();
    public void lieOn();
}
