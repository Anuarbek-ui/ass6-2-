package Task3;

public interface Transport {
    public void deliver();


}
