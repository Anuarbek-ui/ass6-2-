package Task3;

public class Truck implements Transport{
    public void deliver() {
        System.out.println("Delivered by TRUCK");
    }
}
