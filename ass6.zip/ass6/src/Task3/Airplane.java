package Task3;

public class Airplane implements Transport {
    public void deliver() {
        System.out.println("Delivered by AIRPLANE");
    }
}
