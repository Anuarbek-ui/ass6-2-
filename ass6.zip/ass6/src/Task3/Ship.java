package Task3;

public class Ship implements Transport {

    public void deliver() {
        System.out.println("Delivered by Ship");
    }
}
