package Task3;

public enum Transports {
    Ship,Truck
}
